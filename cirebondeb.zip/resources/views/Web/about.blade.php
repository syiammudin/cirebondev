<div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>About Cirebon</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
                <a href="#">
                    <img src="public/template/img/about/1.jpg" alt="">
                </a>
            </div>
          </div>
        </div>
        <!-- single-well end-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
              <a href="#">
                <h4 class="sec-head">project Maintenance</h4>
              </a>
              <p>
                 Kami adalah sekelompok komunitas yang bergelut di bidang IT, kami melayani pemesanan Aplikasi berbasis Web dan Android, kami juga akan membantu menemukan Solusi terbaik untuk digitaslisasi perusahaan anda
              </p>
              <ul>
                <li>
                  <i class="fa fa-check"></i> Web Design
                </li>
                <li>
                  <i class="fa fa-check"></i> Aplikasi Webbase
                </li>
                <li>
                  <i class="fa fa-check"></i> Aplikasi Desktop
                </li>
                <li>
                  <i class="fa fa-check"></i> Aplikasi Mobile
                </li>
                <li>
                  <i class="fa fa-check"></i> Networking dan Maintenance
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
  </div>