<div class="reviews-area hidden-xs">
    <div class="work-us">
      <div class="work-left-text">
          <a href="#">
            <img src="img/about/2.jpg" alt="">
        </a>
      </div>
      <div class="work-right-text text-center">
        <h2>working with us</h2>
        <h5>Web Design, Ready Home, Construction and Co-operate Outstanding Buildings.</h5>
        <a href="#contact" class="ready-btn">Contact us</a>
      </div>
    </div>
  </div>