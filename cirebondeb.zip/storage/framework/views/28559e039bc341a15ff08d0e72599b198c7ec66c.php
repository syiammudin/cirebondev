<footer>
    <div class="footer-area">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head">
                <div class="footer-logo">
                <img src="public/template/img/logo.jpeg" alt="Logo" style="height: 50px;">  
                </div>

                <p>Melayani Jasa pembuatan Website, aplikasi desktop, mobile dan lain lain</p>
                <div class="footer-icons">
                  <ul>
                    <li>
                      <a href="htts//facebook.com/shendarkknight"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-google"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-pinterest"></i></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head">
                <h4>information</h4>
                <p>
                  Butuh layanan kami ? bisa hubungi kontak di bawah ini,
                </p>
                <div class="footer-contacts">
                  <p><span>Tel:</span> +6285797540815</p>
                  <p><span>Email:</span> syiammudin.achmad@gmail.com</p>
                  <p><span>Working Hours:</span> Senin - Jum'at, 9am-5pm</p>
                </div>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head">
                <h4>Instagram</h4>
                <div class="flicker-img">
                  <a href="#"><img src="public/template/img/portfolio/1.jpg" alt=""></a>
                  <a href="#"><img src="public/template/img/portfolio/2.jpg" alt=""></a>
                  <a href="#"><img src="public/template/img/portfolio/3.jpg" alt=""></a>
                  <a href="#"><img src="public/template/img/portfolio/4.jpg" alt=""></a>
                  <a href="#"><img src="public/template/img/portfolio/5.jpg" alt=""></a>
                  <a href="#"><img src="public/template/img/portfolio/6.jpg" alt=""></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-area-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="copyright text-center">
              <p>
                &copy; Copyright <strong>Syiammudin</strong> Website
              </p>
            </div>
            <div class="credits">
              <!--
                All the links in the footer should remain intact.
                You can delete the links only if you purchased the pro version.
                Licensing information: https://bootstrapmade.com/license/
                Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=eBusiness
              -->
              Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer><?php /**PATH /home/syiammudin/app/cirebondev/resources/views/Web/footer.blade.php ENDPATH**/ ?>