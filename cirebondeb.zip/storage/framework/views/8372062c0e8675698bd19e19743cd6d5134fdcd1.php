<div class="suscribe-area">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs=12">
          <div class="suscribe-text text-center">
            <h3>Welcome to our Cirebon Dev comunity</h3>
            <a class="sus-btn" href="#">Get A quate</a>
          </div>
        </div>
      </div>
    </div>
  </div><?php /**PATH /home/syiammudin/app/cirebondev/resources/views/Web/suscrive.blade.php ENDPATH**/ ?>